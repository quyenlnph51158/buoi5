using SD19301_linQ.Models;
using System.Data;

namespace SD19301_linQ
{
    public partial class Form1 : Form
    {
        private BikeStoresContext bkcontext = new BikeStoresContext();
        private DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("ProductId", typeof(int));
            dt.Columns.Add("ProductName", typeof(string));
            dt.Columns.Add("BrandId", typeof(int));
            dt.Columns.Add("CategoryId", typeof(int));
            dt.Columns.Add("ModelYear", typeof(short));
            dt.Columns.Add("ListPrice", typeof(decimal));
            //var listProduct=bkcontext.Products.ToList().OrderBy(p=>p.ProductName);
            //var productDatNhat=bkcontext.Products.ToList().MaxBy(p=>p.ListPrice);
            //var productId100 = bkcontext.Products.ToList().First(p => p.ProductId == 100);
            //var brandNamebyID = bkcontext.Products.ToList();
            var listProduct = bkcontext.Products.ToList().Join(bkcontext.Brands.ToList(),
                p => p.BrandId,
                b => b.BrandId,
                (p, b) => new { p.ProductId, p.ProductName, p.BrandId, p.CategoryId, p.ModelYear, p.ListPrice, b.BrandName }).
                Join(bkcontext.Categories.ToList(),
                a => a.CategoryId,
                c => c.CategoryId,
                (a, c) => new { a.ProductId, a.ProductName, a.BrandId, a.CategoryId, a.ModelYear, a.ListPrice, c.CategoryName, a.BrandName });
            foreach (var product in listProduct)
            {
                DataRow dr = dt.NewRow();
                dr["ProductId"] = product.ProductId;
                dr["ProductName"] = product.ProductName;
                dr["BrandId"] = product.BrandId;
                dr["CategoryId"] = product.CategoryId;
                dr["ModelYear"] = product.ModelYear;
                dr["ListPrice"] = product.ListPrice;
                dt.Rows.Add(dr);
            }
            dgvProducts.DataSource = dt;


        }
        private void search()
        {
            dt.Clear();
            var listProduct = bkcontext.Products.ToList().Join(bkcontext.Brands.ToList(),
                p => p.BrandId,
                b => b.BrandId,
                (p, b) => new { p.ProductId, p.ProductName, p.BrandId, p.CategoryId, p.ModelYear, p.ListPrice, b.BrandName }).
                Join(bkcontext.Categories.ToList(),
                a => a.CategoryId,
                c => c.CategoryId,
                (a, c) => new { a.ProductId, a.ProductName, a.BrandId, a.CategoryId, a.ModelYear, a.ListPrice, c.CategoryName, a.BrandName }).Where(q => q.ProductName.ToLower().Contains(txtprName.Text));

            foreach (var product in listProduct)
            {
                DataRow dr = dt.NewRow();
                dr["ProductId"] = product.ProductId;
                dr["ProductName"] = product.ProductName;
                dr["BrandName"] = product.BrandName;
                dr["CategoryName"] = CategoriesbyID(product.CategoryId).CategoryName;
                dr["ModelYear"] = product.ModelYear;
                dr["ListPrice"] = product.ListPrice;
                dt.Rows.Add(dr);
            }
            dgvProducts.DataSource = dt;
        }

        private Brand brandById(int id)
        {
            return bkcontext.Brands.ToList().FirstOrDefault(b => b.BrandId == id);
        }
        private Category CategoriesbyID(int id)
        {
            return bkcontext.Categories.ToList().FirstOrDefault(b => b.CategoryId == id);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dt.Clear();
            //var listProduct = bkcontext.Products.ToList().Join(bkcontext.Brands.ToList(),
            //    p => p.BrandId,
            //    b => b.BrandId,
            //    (p, b) => new { p.ProductId, p.ProductName, p.BrandId, p.CategoryId, p.ModelYear, p.ListPrice, b.BrandName }).
            //    Join(bkcontext.Categories.ToList(),
            //    a => a.CategoryId,
            //    c => c.CategoryId,
            //    (a, c) => new { a.ProductId, a.ProductName, a.BrandId, a.CategoryId, a.ModelYear, a.ListPrice, c.CategoryName, a.BrandName }).Where(q => q.ProductName.ToLower().Contains(txtprName.Text));
            
            var listProduct = bkcontext.Products.ToList().Where(g => g.ListPrice > 1500);
            foreach (var product in listProduct)
            {
                DataRow dr = dt.NewRow();
                dr["ProductId"] = product.ProductId;
                dr["ProductName"] = product.ProductName;
                dr["BrandId"] = product.BrandId;
                dr["CategoryID"] = product.CategoryId;
                dr["ModelYear"] = product.ModelYear;
                dr["ListPrice"] = product.ListPrice;
                dt.Rows.Add(dr);
            }
            dgvProducts.DataSource = dt;
        }

        private void txtprName_TextChanged(object sender, EventArgs e)
        {
            dt.Clear();
            var listProduct = bkcontext.Products.ToList().Join(bkcontext.Brands.ToList(),
                p => p.BrandId,
                b => b.BrandId,
                (p, b) => new { p.ProductId, p.ProductName, p.BrandId, p.CategoryId, p.ModelYear, p.ListPrice, b.BrandName }).
                Join(bkcontext.Categories.ToList(),
                a => a.CategoryId,
                c => c.CategoryId,
                (a, c) => new { a.ProductId, a.ProductName, a.BrandId, a.CategoryId, a.ModelYear, a.ListPrice, c.CategoryName, a.BrandName }).Where(q => q.ProductName.ToLower().Contains(txtprName.Text));

            foreach (var product in listProduct)
            {
                DataRow dr = dt.NewRow();
                dr["ProductId"] = product.ProductId;
                dr["ProductName"] = product.ProductName;
                dr["BrandName"] = product.BrandName;
                dr["CategoryName"] = CategoriesbyID(product.CategoryId).CategoryName;
                dr["ModelYear"] = product.ModelYear;
                dr["ListPrice"] = product.ListPrice;
                dt.Rows.Add(dr);
            }
            dgvProducts.DataSource = dt;
        }
    }
}
